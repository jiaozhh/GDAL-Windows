
GDAL: v2.3.3 x64

HDF4: v4.2.14
HDF5: v1.10.4-Std-win10_64-vs15
netCDF: v4.6.1-NC4-DAP-64
GEOS: v3.7.1
PROJ: v5.2.0

OS: Windows 10 x64 
Compiler: Visual Studio 2017 v15.9.4

Zhong-Hu Jiao 
jiaozhh@gmail.com
2018.12.22
