

OS: Windows 10 x64
Compiler: Visual Studio 2019 

GDAL v3.0.4
HDF4 v4.2.14
HDF5 v1.10.6
netCDF v4.7.4
GEOS v3.8.0
PROJ v6.3.1


JZH
jiaozhh@126.com
2020.04.16

